Isaac Sim 6.2 initial scene from the lower-layout sensor run.
Open sensor/scene.usdc, keeping assets/ beside sensor/.
The Python controller in labs/worldgen-navigation runs the route; the USD is the initial setup.
WorldGen/FLUX generated room, assumed 1.5 m camera height. Explicit local floor and added boxes.
Authored robot and source: repository MIT. Isaac Sim, sensor schemas and OmniPBR.mdl: NVIDIA runtime terms.
No model weights or NVIDIA runtime files are redistributed. See SPATIAL-CREDITS.md.
