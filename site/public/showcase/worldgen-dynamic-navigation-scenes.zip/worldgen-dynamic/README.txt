Initial Isaac Sim 6.2 scenes, not animations. Open gate/scene.usdc or cart/scene.usdc; keep assets/ beside both.
Run the Python lab for robot control and kinematic obstacle motion. The visible moving body mirrors actual PhysX transforms each step.
Original code and authored robot/geometry: repository MIT. Generated WorldGen/FLUX output provenance: SPATIAL-CREDITS.md.
Isaac Sim, physics sensor schemas and OmniPBR runtime retain NVIDIA terms; no runtime or model weights are redistributed.
